import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		// Calculate the energy required (Joules) to raise the temperature to a final temperature (degrees Celsius)  with of a mass of water (kilograms)
		
		Scanner input = new Scanner(System.in);

		System.out.print("Enter the amount of water in kilograms: ");
		
		double massofwater = input.nextDouble();
		
		System.out.print("Enter the initial and final temperatures in degrees Celsius: ");
		
		double initialtemperature = input.nextDouble();
		double finaltemperature = input.nextDouble();
		
		System.out.println("The energy needed is " + (massofwater*(finaltemperature-initialtemperature)*4184) + " joules.");
		
	input.close();
	}

}
