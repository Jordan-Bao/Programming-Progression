import java.util.Scanner;

public class Q1 
{ 
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	//Bubble sorter for 3 numbers
	
	System.out.print("Enter three integers: ");
	int user1 = input.nextInt();
	int user2 = input.nextInt();
	int user3 = input.nextInt();

	if (user1>user2)
		{int holder = user1;
		user1 = user2;
		user2=holder;}
	
	if (user2>user3)
		{int holder = user2;
		user2 = user3;
		user3=holder;}
	
	if (user1>user2)
	{int holder = user1;
	user1 = user2;
	user2=holder;}
	
	System.out.printf("The sorted numbers: %d %d %d", user1, user2, user3);
	
	input.close();
	}
}