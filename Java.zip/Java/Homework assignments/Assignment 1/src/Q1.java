
public class Q1 {
	
	public static void main(String[] args) {
		//Create UBC design
		
		System.out.println("U   U   B B       C C");
		System.out.println("U   U   B   B   C  ");
	    System.out.println("U   U   B B     C  ");
	    System.out.println("U   U   B   B   C  ");
	    System.out.println(" U U    B B       C C");
	}
}
