
public class Cuboid {

// Attributes
private double l;
private double w;
private double h;
private String color; 

//Constructors
public Cuboid(double cuboidL, double cuboidW, double cuboidH, String cuboidColor){
	l = cuboidL;
	w = cuboidW;
	h = cuboidH;
	color =  cuboidColor;
}
public Cuboid(){
	this.l=1;
	this.w=1;
	this.h=1;
	this.color="White";
}

//Methods
public double getL(){
	return l;
}
public double getW(){
	return w;
}
public double getH(){
	return h;
}
public String getColor(){
	return color;
}
public double getSurfaceArea(){
	double cuboidSurfaceArea = 2*(l*w+l*h+w*h);
	return cuboidSurfaceArea;
}
public double getVolume(){
	double cuboidVolume =l*w*h;
	return cuboidVolume;
}
public void displayInfo(){
	double cuboidSA = getSurfaceArea(); 
	double cuboidV = getVolume();
	System.out.printf("  Color: %s\n  Dimensions: %.2f X %.2f X %.2f\n  Surface Area: %.2f\n  Volume: %.2f\n"
						,color, l, w, h, cuboidSA, cuboidV);
}

}
