
public class Q2 {

	public static void main(String[] args) {
		//Create a table
		
		System.out.println("x   x^5  x^10");
		System.out.println("1   1    1");
		System.out.println("2   32   1024");
		System.out.println("3   243  59049");
	}

}
