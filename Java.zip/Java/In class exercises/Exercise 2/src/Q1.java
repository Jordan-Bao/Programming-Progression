import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		
		// Calculate user's age in 2015 from their inputs
		
		System.out.println("What is your name?" );
		
		/*Use a scanner for an input*/
		Scanner input = new Scanner(System.in);
		String name = input.nextLine();
		
		System.out.println("What is your birth year?");
		
		Long birthyear = input.nextLong();
		
		System.out.println("Hello " + name);
		System.out.println("You are " + (2015-birthyear) + " years old.");

	input.close();
	}

}
