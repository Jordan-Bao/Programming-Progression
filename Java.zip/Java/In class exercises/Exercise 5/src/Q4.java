import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		//Print a pattern
		
		System.out.print("Enter an integer: ");
		int user = in.nextInt();
		System.out.println();
		System.out.println("Pattern I");

		//format the lines
		for (int print = 1; print<=2*user; print++)
		{System.out.print('-');}
		
		//print pattern
		System.out.printf("%n");
		int row = 1;
		int number = 1;
		
		//control number of rows
		for (row = 1; row<=user; row++){
		
		//control number of numbers
		while ((number<=user) & (number<=row)) {System.out.print(number + " "); number++;}
		
		//reset for each row
		System.out.printf("%n"); number = 1;}	
	
		System.out.printf("%n");
		
		System.out.println("Pattern II");
		
		//same amount of lines for second pattern
		for (int print = 1; print<=2*user; print++)
		{System.out.print('-');}
		
		//print pattern, reset previous iteration
		number = 1;
		for(row = 0; row<=user; row++) //Row has to equal zero to increment from one to user value for the next few lines.
			{
			System.out.printf("%n"); 
			while ((number<=user-row))
			{System.out.print(number + " "); number++;}
			number = 1;
			}
		in.close();
		}
	}


