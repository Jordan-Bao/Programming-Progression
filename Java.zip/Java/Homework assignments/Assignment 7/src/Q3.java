import java.util.Scanner;

public class Q3{
	public static void main(String[] args) 
		{
		String s1 = "How many numbers in the list? ";
		String s2 = "Enter the list: ";

		double[] list = getNumsFromUser(s1, s2);
		
		if (isSorted(list)==true)
		{System.out.println("The list is already sorted");}
		
		else if (isSorted(list)==false) 
		{System.out.println("The list is not sorted");}
		
		}
	
			public static double[] getNumsFromUser(String msg1, String msg2)
			{
				Scanner in = new Scanner(System.in);
	
				System.out.print(msg1);
				int students = in.nextInt();
				System.out.print(msg2);
				double [] markarray = new double[students];
				
				for (int x = 0; x<students; x++) 
				{markarray[x] = in.nextDouble();}
				
				in.close();
				return markarray;
			}
			
			//Q3
			public static boolean isSorted(double[] list) 
			{	
				int maxlength = list.length; //limit the loop
				boolean sort = true; 
				
				for (int a=0; sort==true & a<maxlength-1; a++) //make 1 less comparison than the total 
				{											   //number of elements to avoid out of bounds
					if (list[a]<=list[a+1]) {sort = true;}
					else if (list[a]>list[a+1]){sort = false;}
				}
				return sort;
			}
	}