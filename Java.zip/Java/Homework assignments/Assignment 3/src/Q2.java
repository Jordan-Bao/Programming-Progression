import java.util.Scanner;

public class Q2 { 
	public static void main(String[] args) {
		
		/* Show the integer and decimal part of a real number input separately*/
		
		Scanner in = new Scanner(System.in);
		
		System.out.printf("Enter a real number: ");
		double realnumber = in.nextDouble();
		
		//Find the integer part
		int integerpart = (int)realnumber;
		
		//Get rid of integer part of the real number
		double decimalpart = realnumber - integerpart;
		
		System.out.printf("Integer part: %d %nFraction part: %f %n", integerpart, decimalpart);
		
		in.close();
	}
}
