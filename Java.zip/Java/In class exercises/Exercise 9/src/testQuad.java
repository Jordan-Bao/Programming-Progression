import java.util.Scanner;
public class testQuad {

	public static void main(String[] args) {
		
		Scanner in = new Scanner (System.in);
		
		System.out.print("Enter a, b, c: ");
		int a = in.nextInt();
		int b = in.nextInt();
		int c = in.nextInt();
		
		QuadraticEquation quad = new QuadraticEquation(a,b,c);
		
		if (quad.getDiscriminant()<0)
			System.out.println("The equation has no real roots");
		
		else if (quad.getDiscriminant()==0)
			System.out.printf("The root is %.1f", quad.getRealRoot1());
		
		else System.out.printf("The roots are %.1f and %.1f", quad.getRealRoot1(), quad.getRealRoot2());
		
		in.close();
	}

}
