import java.util.Scanner;


public class Q3 {

	public static void main(String[] args) {
		// Calculate BMI of a user with their weight in pounds and height in inches
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter weight in pounds: ");
		
		double userweightinpounds = input.nextDouble();
		double userweightinkilograms = userweightinpounds/2.205;
		
		System.out.print("Enter your height in inches: ");
		
		double userheightininches = input.nextFloat();
		double userheightinmeters = userheightininches*0.0254; 
		
		System.out.println("Your BMI is " + userweightinkilograms/(userheightinmeters*userheightinmeters));
		
	input.close();
		
		
	}

}
