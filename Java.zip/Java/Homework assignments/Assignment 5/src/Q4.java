import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		// Find top two students
		Scanner in = new Scanner(System.in);
		
		//initialize variables
		String firstname = "";
		String secondname = "";
		double firstscore = 0;
		double secondscore = 0; 
		
		System.out.print("Enter the number of students: ");
		int number = in.nextInt();
		
		for(int x = 1; x<=number; x++){
			System.out.print("Enter a student name: ");
			String name = in.next();
			
			System.out.print("Enter a student score: ");
			double score = in.nextDouble();
			
			
			//store as high scores if they are higher than 1st or 2nd place
			if (score>firstscore){
				secondscore = firstscore; //need to move first into second place first or else this data will be lost
				secondname = firstname;
				firstscore = score;
				firstname = name;}
			else if (score>secondscore){
				secondscore = score;
				secondname = name;}
		}
		
	//show top 2
	System.out.println("Top two students: ");	
	System.out.printf("%s's score is %.1f", firstname, firstscore);
	System.out.printf("%n%s's score is %.1f", secondname, secondscore);
	
	in.close();
	}

}
