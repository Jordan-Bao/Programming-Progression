
public class Stock {

	@SuppressWarnings("unused")
	private String symbol;
	private String name;
	private double prevClosingPrice;
	private double currentPrice;
	
//This is the constructor method sets attribute values while creating the specific object
	public Stock(String aSymbol, String aName){
		symbol = aSymbol;
		name = aName;
	}

public String getName(){
	return name;
	}

public void setName(String newName){
	name = newName;
	}

public double getPrevClosingPrice(){
	return prevClosingPrice;
	}

public void setPrevClosingPrice(double newPrevClosingPrice){
	prevClosingPrice = newPrevClosingPrice;
	}

public double getCurrentPrice(){
	return currentPrice;
	}

public void setCurrentPrice(double newCurrentPrice){
	currentPrice = newCurrentPrice;
	}

public String getChangePercent(){
	double percentChange = (currentPrice-prevClosingPrice)/prevClosingPrice*100;
	String change = percentChange + "%";
	return change;
	}
}