
public class Q4 {

	public static void main(String[] args) {
		// Calculate an expression
		
		System.out.println((3*4.5+5*7.1)/(7.2*5.5));

	}

}
