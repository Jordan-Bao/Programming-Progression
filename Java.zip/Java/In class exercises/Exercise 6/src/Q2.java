
public class Q2 {

	public static void main(String[] args) {
		for(int year=2000; year<=2010; year++){
			int days = numberOfDaysInAYear(year);
			System.out.printf("%d has %d%n", year, days);
		}

	}
	
	public static boolean isLeapYear(int year){
		
		boolean isLeapYear;
		
		if((year%4==0)&(year%100!=0)|(year%400==0)){
		isLeapYear = true;}
		else{isLeapYear = false;}
		
		return isLeapYear;
	}
	
	public static int numberOfDaysInAYear(int year){
		int numberOfDaysInAYear;
		
		if ((year%4==0)&(year%100!=0)|(year%400==0)){
			numberOfDaysInAYear = 366;}
		else {numberOfDaysInAYear = 365;}
		
		return numberOfDaysInAYear;
	}
}
