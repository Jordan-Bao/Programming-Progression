import java.util.Scanner;
public class Test {
	public static void main (String[] args ) {
		Scanner input = new Scanner(System.in);
		System.out.println("How fast was the vehicle going?");
		int speed = input.nextInt();
		System.out.println("What was the speed limit?");
		int limit = input.nextInt();
		
		int difference = speed-limit;
		
		System.out.println("Was it a school or construction zone? (1 for yes 2 for no)");
		int zone = input.nextInt();
		
	switch (zone) {
	case 1 : if (difference>=61) { 
		System.out.println("The fine is $483");}
		else if (difference>=41) {
			System.out.println("The fine is $368");}
			else if (difference>=21) {
				System.out.println("The fine is $253");}
			else if (difference>=1)
			{System.out.println("The fine is $196");}
			else if (difference<=-20)
			{System.out.println("The fine is $121");}
			else {System.out.println("The speed limit is obeyed");}
			break;
			
	case 2: if (difference>=61) { 
		System.out.println("The fine is $483");}
		else if (difference>=41) {
			System.out.println("The fine is $368");}
			else if (difference>=21) {
				System.out.println("The fine is $196");}
			else if (difference>=1)
			{System.out.println("The fine is $138");}
			else if (difference<=-20)
			{System.out.println("The fine is $121");}
			else {System.out.println("The speed limit is obeyed");}
			break;
	default : System.out.println("Check the zone value. (1 for yes 2 for no)");		
				}
	input.close();
			}
       
	}

