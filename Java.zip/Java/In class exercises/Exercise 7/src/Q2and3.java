import java.util.Scanner;
public class Q2and3 {

	public static void main(String[] args) {
		Scanner ten = new Scanner(System.in);
		
		double array [] = new double [10];
		System.out.print("Enter ten numbers: ");
		for(int x=0; x<10;x++){
			array[x] = ten.nextDouble();
		}
		int minindex = indexOfMin(array);
		double minvalue = getMin(array);
		System.out.printf("The min is %.1f%n", minvalue);
		System.out.println("The index of the min is " + minindex);
		ten.close();
	}
	
public static int indexOfMin(double[]array){
	
	int indexOfMin = 0;
	for (int i = 1 ; i<array.length; i++)
	{
		if (array[i]<array[indexOfMin])
		{
			indexOfMin=i;
		}
	}
	return indexOfMin;
}

public static double getMin(double[]array)
	{
	double minvalue = array[0];
	for (int t=1; t<array.length; t++)
		{
		if (array[t]<minvalue)
		{
		minvalue = array[t];	
		}
		}
		return minvalue;
	}
}

