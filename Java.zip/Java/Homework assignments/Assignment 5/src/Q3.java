
public class Q3 {

	public static void main(String[] args) {
		// Find numbers from 100-200 that are XOR divisible by 5, 6
		int counter = 1;
		
		for (int x=100; x<=200; x++){
		if ((x%5==0)^(x%6==0)){
			System.out.print(x + " ");
			
			//track number of times numbers are printed
			if (counter==10){
				counter = 0; //zero because the next number has not been printed yet
			System.out.printf("%n");}
			counter++;
			
			}
		}

	}

}
