
public class QuadraticEquation {
private int a;
private int b;
private int c;

public QuadraticEquation(int a1, int b1, int c1){
	a = a1;
	b = b1;
	c = c1;
	}

public int getA(){
	return a;
	}
public int getB(){
	return b;
	}
public int getC(){
	return c;
	}

public double getDiscriminant(){
	return Math.pow(b, 2) - 4*a*c;
	}

public double getRealRoot1(){
	if (getDiscriminant()<0)
		return 0;
	
	else return (-b+Math.sqrt(getDiscriminant()))/(2*a); 
	}
public double getRealRoot2(){
	if (getDiscriminant()<0)
		return 0;
	
	else return (-b-Math.sqrt(getDiscriminant()))/(2*a); 
	}

}
