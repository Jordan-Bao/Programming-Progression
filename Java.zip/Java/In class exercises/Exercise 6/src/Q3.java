import java.util.Scanner;
public class Q3 {
	
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a password: ");
		String s = in.nextLine();
		if (isValidPassword(s)==true){System.out.println("Valid");}
		else {System.out.println("Invalid");}
	in.close();	
	}

	public static boolean isValidPassword(String s){
	
		int stringsize = s.length();
		int invalidcharacters = 0;
		int numberofdigits = 0;
		
		for (int checker = 0; checker<stringsize; checker++){
			char now = s.charAt(checker);
			boolean isletter = Character.isAlphabetic(now);
			boolean isnumber = ((now>=48)&(now<=57));
			if ((isletter==false)&(isnumber==false)) {invalidcharacters++;}
			if (isnumber==true){numberofdigits++;} 		
		}
		
		if ((stringsize>=8)&(invalidcharacters==0)&(numberofdigits>=2))
			{return true;}
		else {return false;}		
	}
}
