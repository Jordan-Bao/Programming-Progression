import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
		// Step 1: Create a 2d array holding the provinces and answers
		
		String [][] quiz = { {"Alberta","Edmonton"},
							 {"British Columbia", "Victoria"},
							 {"Manitoba", "Winnipeg"},
							 {"New Brunswick", "Fredericton"},
							 {"Newfoundland and Labrador", "St. John's"},
							 {"Nova Scotia", "Halifax"},
							 {"Ontario", "Toronto"},
							 {"Prince Edward Island", "Charlottetown"},
							 {"Quebec", "Quebec City"},
							 {"Saskatchewan", "Regina"} };
		
		//Step 2: use loops and scanners to ask questions and input answers
		Scanner in = new Scanner(System.in);
		
		int right = 0; //tracks right answers
		
		for (int x=0; x<quiz.length; x++) {
			System.out.printf("What is the capital of %s? ", quiz[x][0]); //always the first column in the question
			String answer = in.nextLine();
			if (answer.equalsIgnoreCase(quiz[x][1]))
				right++;
		}
			
		//Step 3: output results
		System.out.printf("You got %d question(s) right.", right);
			in.close();
	}

}
