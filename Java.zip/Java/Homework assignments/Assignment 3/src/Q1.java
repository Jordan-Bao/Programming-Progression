import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		// Calculate wind-chill temperature with math containers
		
		Scanner input = new Scanner(System.in);
		
		/*initialize required variables*/
		double fahrenheittemperature ;
		double windspeed ;
		
		/*prompt user to enter the values*/
		System.out.printf("Enter the temperature in Fahrenheit between -58 F and 41 F: ");
		fahrenheittemperature = input.nextDouble();
		
		System.out.printf("Enter the wind speed miles per hour (must be greater or equal to 2) : ");
		windspeed = input.nextDouble();
		
		/* declare calculation */
		double windchill = 35.74 + 0.6215*fahrenheittemperature - 35.75*Math.pow(windspeed,0.16) 
						   + 0.4275*fahrenheittemperature*Math.pow(windspeed,0.16);
		
		/*show wind-chill*/
		
		System.out.printf("The wind chill index is %.15f", windchill);

		input.close();		
	}

}
