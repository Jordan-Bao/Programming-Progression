
public class Q2 {
	
	//Calculate area and perimeter of a rectangle
	
	public static void main (String[] args){
		double width = 7;
		double height = 9;
		double area = width*height;
		double perimeter = 2*width+2*height;
		
		System.out.println("Area: " + area);
		System.out.println("Perimeter: " + perimeter);
	}
}
