
public class StopWatch {

	private long startTime;
	private long endTime;


public void start(){
	startTime = System.currentTimeMillis();
	}

public void stop(){
 	endTime = System.currentTimeMillis(); //this is a java method, cool
	}

public long getElapsedTime(){
	return endTime-startTime; //you can have operations in return statement
	}
}