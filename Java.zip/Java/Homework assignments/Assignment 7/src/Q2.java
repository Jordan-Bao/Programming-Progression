import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		
			String s1 = "Enter number of students: ";
			String s2 = "Enter student grades: ";
			double[] numbers = getNumsFromUser(s1, s2);
			showLetterGrades(numbers);}
		
public static double[] getNumsFromUser(String msg1, String msg2)
			{
				Scanner in = new Scanner(System.in);
				System.out.print(msg1);
				int students = in.nextInt();
				System.out.print(msg2);
				double [] markarray = new double[students];
				for (int x = 0; x<students; x++) 
				{markarray[x] = in.nextDouble();}
				in.close();
				return markarray;
			}
			
			//Q2 Method
public static void showLetterGrades(double[] grades) 
			{
				int length = grades.length; 
				
				//First find best
				double best = 0;
				for (int x=0; x<length; x++) 
				{if (grades[x]>best) {best=grades[x];}}
				
				//Compare and assign a letter grade for each mark
				for(int a=0; a<length; a++)
				{ char letter;
					if (grades[a]>=best-10) {letter='A';}
					else if (grades[a]>=best-20) {letter='B';}
					else if (grades[a]>=best-30) {letter='C';}
					else if (grades[a]>=best-40) {letter='D';}
					else {letter='F';}
					System.out.printf("Student %d score is %.1f and grade is %c\n", a+1, grades[a], letter);
				}
			}
	}
