import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
		/* Sum up the numbers in an integer between 0 and 1000*/
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an integer between 0 and 1000: ");
		int user = input.nextInt();
		
		//find 1000s
		int thousands = user/1000;
		
		//find 100s
		int hundreds = user%1000/100;
		
		//find 10s
		int tens = user%100/10;
		
		//find 1s
		int ones = user%10;
		
		//find the sum
		int sum = thousands + hundreds + tens + ones;
		
		System.out.printf("The sum of all digits in %d is %d", user, sum);
		
		input.close();
	}

}
