import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
				
		System.out.print("Enter the first integer (0 to terminate): ");
		
		int number = in.nextInt();
		
		//set up trackers
		int total = number;
		int loops = 0; 
		int positives = 0;
		int negatives =0;
		int evens = 0;
		int odds =0 ;
		
		//first line is not in a loop yet
		if (number==0){
		in.close();
		System.out.println("no numbers are entered except 0");
		return; }
		if (number>0){positives++;}
		if (number<0){negatives++;}
		if (number%2==0){evens++;}
		if (number%2!=0){odds++;}
		
		//let the user do something before the above loop, but next instead of first
		do {
			System.out.print("Enter the next integer (0 to terminate): ");
			number = in.nextInt();
			if (number>0){positives++;}
			if (number<0){negatives++;}
			if ((number%2==0)&(number!=0)){evens++;}
			if ((number%2!=0)&(number!=0)){odds++;}
			loops++;
			total +=number;
		}while(number!=0);
		
		//calculate average
		double average = (double)total/loops;
		
		//show the results
		System.out.println("The number of positives is " + positives);
		System.out.println("The number of negatives is " + negatives);
		System.out.println("The number of evens is " + evens);
		System.out.println("The number of odds is " + odds);
		System.out.println("The total is " + total);
		System.out.printf("The average is %.2f", average);
		
		in.close();
	}

}
