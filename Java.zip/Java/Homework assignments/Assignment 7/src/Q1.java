import java.util.Arrays;
import java.util.Scanner;

public class Q1{
	public static void main(String[] args) 
		{
		String s1 = "Enter number of students: ";
		String s2 = "Enter student grades: ";
		//Q1 method
		double[] numbers = getNumsFromUser(s1, s2);
		System.out.println(Arrays.toString(numbers));
		}
	
		//Q1
			public static double[] getNumsFromUser(String msg1, String msg2)
			{
			//Plan: Show msg1 & msg2, letting the user in between. 
				Scanner in = new Scanner(System.in);
			//Store msg1 input as array length. Store second input as an array
				
				//Show and let user input
				System.out.print(msg1);
				int students = in.nextInt();
				System.out.print(msg2);
				double [] markarray = new double[students];
				
				//Store multiple inputs at once inside an array
				for (int x = 0; x<students; x++) 
				{markarray[x] = in.nextDouble();}
				
				in.close();
				return markarray;
			}
			
		}

