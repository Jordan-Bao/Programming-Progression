import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		// user plays scissor-paper-rock versus the computer
		
	//user enters their move	
		System.out.print("scissor (0), rock (1), paper (2): ");
		int input = in.nextInt();
		String usermove = null;
		
		switch(input) {
		case 0: usermove = "scissor"; break;
		case 1: usermove = "rock"; break;
		case 2: usermove = "paper"; break;
		default: System.out.println("Invalid entry. Enter 0 for scissor, or 1 for rock, or 2 for paper");
		}
		
	//computer generates its' move
		int computer = (int)(3*Math.random());
		String computermove = null;
		
		switch (computer) {
		case 0: computermove = "scissor"; break;
		case 1: computermove = "rock"; break;
		case 2: computermove = "paper"; break;
		}//no default statement since no other possible generated value
		
	//Evaluate the outcome
		//draw
		if (computer==input) {
		System.out.printf("The computer is %s. You are %s. Draw", computermove, usermove);
		}
		//user won
		if((computer==0 & input==1)|(computer==1 & input==2)|(computer==2 & input==0)) {
		System.out.printf("The computer is %s. You are %s. You won", computermove, usermove);	
		}
		//the computer won
		if((computer==1 & input==0)|(computer==2 & input==1)|(computer==0 & input==2)) {
		System.out.printf("The computer is %s. You are %s. The computer won", computermove, usermove);	
		}
		
		in.close();
	}

}
