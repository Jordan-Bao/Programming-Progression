
public class Q3 {
	
	public static void main(String[] args) {
		//Generate a random upper case letter of the alphabet
		
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		char randomletter = alphabet.charAt((int)(26*Math.random()));
		
		System.out.println(randomletter);
		
		
	}
}
