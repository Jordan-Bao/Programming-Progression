import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		// Calculate acceleration from inputed initial, final velocities, and time taken
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter v0, v1 and t: ");
		double initialvelocity = input.nextDouble();
		double finalvelocity = input.nextDouble();
		double time = input.nextDouble();
		
		/*Calculate acceleration*/
		double acceleration = (finalvelocity-initialvelocity)/time;
		
		System.out.println("The average acceleration is " + acceleration);
		
	input.close();

	}

}
