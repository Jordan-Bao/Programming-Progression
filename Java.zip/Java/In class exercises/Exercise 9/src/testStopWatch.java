import java.util.Arrays;

public class testStopWatch {

	public static void main(String[] args) {
		StopWatch gogo = new StopWatch();

		gogo.start();

		double [] create = new double [1000000];

		for (int i = 0; i<create.length; i++){
			create[i] = Math.random();
		}
		
		Arrays.sort(create);
		
		gogo.stop();
		
		System.out.println("The elapsed time is " + gogo.getElapsedTime() + " ms");
		
		
	}

}
