import java.util.Scanner;
public class Q2
{

	public static void main(String[] args){
	 /*Make the user guess a 50/50 coin flip*/
		Scanner input = new Scanner(System.in);
		
		System.out.print("Guess head or tail (H or T)? ");
		char guess = input.next().charAt(0);
		
		char result ='0'; //initialize the variable
		String answer = "";
		int coin = (int)(Math.round(Math.random()));
		if (coin==0){result = 'H'; answer = "head";}
		if (coin==1){result = 'T'; answer = "tail";}
		
		//accept both capital and lower case inputs
		if ((guess==result)|(guess==result+32)){System.out.println("Correct guess");}
		if ((guess!=result)&(guess!=result+32)){System.out.println("Sorry, it is a " + answer);}
		
		input.close();
	}

}
