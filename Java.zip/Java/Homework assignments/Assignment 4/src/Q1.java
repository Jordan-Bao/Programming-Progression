import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		// Vowel and consonant checker
		
		
		System.out.print("Enter a letter: ");
		String user = in.next(); //No scanner for specific characters
		
		int isletter = user.length(); //Check if the user only entered one character
		if (isletter>1) {System.out.println(user + " is an invalid input");}
		
		else switch(user.charAt(0)) { //check for capital and lower case letters
		case 65 : System.out.println(user + " is a vowel");break;
		case 66 : System.out.println(user + " is a consonant"); break;
		case 67 : System.out.println(user + " is a consonant"); break;
		case 68 : System.out.println(user + " is a consonant"); break;
		case 69 : System.out.println(user + " is a vowel");break;
		case 70 : System.out.println(user + " is a consonant"); break;
		case 71 : System.out.println(user + " is a consonant"); break;
		case 72 : System.out.println(user + " is a consonant"); break;
		case 73 : System.out.println(user + " is a vowel");break;
		case 74 : System.out.println(user + " is a consonant"); break;
		case 75 : System.out.println(user + " is a consonant"); break;
		case 76 : System.out.println(user + " is a consonant"); break;
		case 77 : System.out.println(user + " is a consonant"); break;
		case 78 : System.out.println(user + " is a consonant"); break;
		case 79 : System.out.println(user + " is a vowel"); break;
		case 80 : System.out.println(user + " is a consonant"); break;
		case 81 : System.out.println(user + " is a consonant"); break;
		case 82 : System.out.println(user + " is a consonant"); break;
		case 83 : System.out.println(user + " is a consonant"); break;
		case 84 : System.out.println(user + " is a consonant"); break;
		case 85 : System.out.println(user + " is a vowel"); break;
		case 86 : System.out.println(user + " is a consonant"); break;
		case 87 : System.out.println(user + " is a consonant"); break;
		case 88 : System.out.println(user + " is a consonant"); break;
		case 89 : System.out.println(user + " is a vowel"); break;
		case 90 : System.out.println(user + " is a consonant"); break;
		case 97 : System.out.println(user + " is a vowel"); break;
		case 98 : System.out.println(user + " is a consonant"); break;
		case 99 : System.out.println(user + " is a consonant"); break;
		case 100 : System.out.println(user + " is a consonant"); break;
		case 101 : System.out.println(user + " is a vowel"); break;
		case 102 : System.out.println(user + " is a consonant"); break;
		case 103 : System.out.println(user + " is a consonant"); break;
		case 104 : System.out.println(user + " is a consonant"); break;
		case 105 : System.out.println(user + " is a vowel"); break;
		case 106 : System.out.println(user + " is a consonant"); break;
		case 107 : System.out.println(user + " is a consonant"); break;
		case 108 : System.out.println(user + " is a consonant"); break;
		case 109 : System.out.println(user + " is a consonant"); break;
		case 110 : System.out.println(user + " is a consonant"); break;
		case 111 : System.out.println(user + " is a vowel"); break;
		case 112 : System.out.println(user + " is a consonant"); break;
		case 113 : System.out.println(user + " is a consonant"); break;
		case 114 : System.out.println(user + " is a consonant"); break;
		case 115 : System.out.println(user + " is a consonant"); break;
		case 116 : System.out.println(user + " is a consonant"); break;
		case 117 : System.out.println(user + " is a vowel"); break;
		case 118 : System.out.println(user + " is a consonant"); break;
		case 119 : System.out.println(user + " is a consonant"); break;
		case 120 : System.out.println(user + " is a consonant"); break;
		case 121 : System.out.println(user + " is a vowel"); break;
		case 122 : System.out.println(user + " is a consonant"); break;
		default : System.out.println(user + " is an invalid input"); break;
		}
		in.close();
	}

}
