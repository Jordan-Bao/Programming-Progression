
public class Q1 {

	public static void main(String[] args) {
		// Find smallest n such that n^2 > 12000
int n = 1;
while (Math.pow(n,2)<12000){n++;}
System.out.println(n); //it's 110
	

	}

}
