import java.util.Scanner;
public class Q4 {
	public static void main(String args[]){
		//Output the length, and the capitalized first character of an input string. 
		//Also display if that string contains the letter x. Do all of the above only using printf
		
		Scanner input = new Scanner(System.in);
		
		/*User enters a string*/
		System.out.printf("Enter a sting: ");
		String words = input.nextLine();
		
		/*Find the length of string, its first letter*/
		int length = words.length();
		char firstletter = words.charAt(0);
		
		/*Convert the string to all upper case letters to find if there is an x*/
		String capital = words.toUpperCase();
		int istherex = capital.indexOf("X");
		
		if (istherex == 0) { istherex = istherex+1;} /*to comply with the required statement below (x cannot equal 0)*/
		
		System.out.printf("The length of %S is %d. \nThe first character of %S is %C. \nDoes %S includes the letter X (-ve value for NO, +ve value for YES)? %d", words, length, words, firstletter, words, istherex);
		
		input.close();
		
		
	}
	
}
