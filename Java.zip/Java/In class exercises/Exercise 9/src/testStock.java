
public class testStock {

	public static void main(String[] args) {
		Stock sunw = new Stock("SUNW", "Sun MicroSystems Inc.");
		
		sunw.setPrevClosingPrice(34.5);
		sunw.setCurrentPrice(34.35);
		
		System.out.println("Stock name: " + sunw.getName());
		System.out.println("Previous Closing Price: " + sunw.getPrevClosingPrice());
		System.out.println("Current Price: " + sunw.getCurrentPrice());
		System.out.println("Price Change: " + sunw.getChangePercent());
	}

}
