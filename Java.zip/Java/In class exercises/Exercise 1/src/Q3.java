
public class Q3 {

	public static void main(String[] args) {
		//Calculate area of circle 
		
		/*State variables and constants*/
		final double Pi = 3.14159;
		double radius = 5.5;
		double perimeter = 2*Pi*radius;
		double area = Pi*radius*radius;
		
		/*Calculate and output*/
		System.out.println("Area: " + area + " units^2");
		System.out.println("Perimeter: " + perimeter + " units");		
	}
}