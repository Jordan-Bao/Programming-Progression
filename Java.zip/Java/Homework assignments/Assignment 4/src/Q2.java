import java.util.Scanner;
public class Q2 {
	public static void main (String[] args) {
	Scanner in = new Scanner(System.in);
	
	System.out.print("Enter a valid plate number ");
	String plate = in.nextLine();
	
	//plate is too long or short
	if (plate.length()!=5){System.out.println(plate + " is an invalid plate number");}
	
	//first 2 characters are not upper case
	else if (plate.charAt(0)<65|plate.charAt(0)>90){System.out.println(plate + " is an invalid plate number");}
	else if (plate.charAt(1)<65|plate.charAt(0)>90){System.out.println(plate + " is an invalid plate number");}
	
	//3rd character is not a dash
	else if (plate.charAt(2)!=45){System.out.println(plate + " is an invalid plate number");}
	
	//last two characters are not numbers
	else if (plate.charAt(3)<48|plate.charAt(3)>57){System.out.println(plate + " is an invalid plate number");}
	else if (plate.charAt(4)<48|plate.charAt(4)>57){System.out.println(plate + " is an invalid plate number");}
	
	//all the above have passed
	else {System.out.println(plate + " is a valid plate number");}
	
	in.close();
	}
}
