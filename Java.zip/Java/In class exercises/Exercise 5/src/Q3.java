import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		//Reverse a string, count vowels, and upper case letters

		//Prompt the user to enter a string
		System.out.print("Enter a string: ");
		String words = in.nextLine();
		
		//Store the entered values into a reversed string array
		System.out.print("The reversed string is " + '"');
		//These are the vowel and upper case counters
		int vowel = 0;
		int upper = 0;
		
		int x = words.length()-1;
		char array [] = new char [words.length()];
		while (x>=0)
		{ //reverse the string
		array[x] = words.charAt(x);
		System.out.print(array[x]);	
		//check if it's a vowel
		if ((words.charAt(x) == 65)|(words.charAt(x) == 69)|(words.charAt(x) == 73)|(words.charAt(x) == 79)|(words.charAt(x) == 85)|
		(words.charAt(x) == 89)|(words.charAt(x) == 97)|(words.charAt(x) == 101)|(words.charAt(x) == 105)|(words.charAt(x) == 111)|
		(words.charAt(x) == 117)|(words.charAt(x) == 121))
			{vowel++;}
		//check if it's a capital letter
		if ((words.charAt(x) >= 65)&(words.charAt(x) <= 90))
			{upper++;}
		x--;
		}
		
		System.out.println('"');
		System.out.println("The number of vowels is " + vowel);
		System.out.println("The number of uppercase letters is " + upper);
		
		in.close();
	}

}
