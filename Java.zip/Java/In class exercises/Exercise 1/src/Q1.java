
public class Q1 {

	public static void main(String[] args) {
		
		//Writing my name in two ways
		
		/* only using system out*/
		
		System.out.println("Jordan Bao Jordan Bao Jordan Bao Jordan Bao Jordan Bao Jordan Bao");
		
				}
	

}
