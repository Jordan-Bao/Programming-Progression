
public class BankAccount {
	
//Attributes
private int id;
private double balance;
private double annualInterestRate;
private static int count;

//Constructor Invoking 
	public BankAccount(double accountAnnualInterestRate, double accountBalance){
	annualInterestRate = accountAnnualInterestRate;
	balance = accountBalance;
	count++;
	id = count;
	}
	
	public BankAccount(){
		this(0, 0);	
	}
	
//Methods	
public double getBalance(){
	return balance;
}
public double getAnnualInterestRate(){
	return annualInterestRate;
}
public int getId(){
	return id;
}
public void setBalance(double newBalance){
	balance = newBalance;
}
public void setAnnualInterestRate(double newAnnualInterestRate){
	annualInterestRate = newAnnualInterestRate;
}
public double getMonthlyInterest(){
	double monthlyInterest = balance*(annualInterestRate/100)/12.0;
	return monthlyInterest;
}
public void withdraw(int x){
	balance -= x;
}
public void deposit(int x){
	balance += x;
}
public void displayInfo(){
	double monthlyInterest = getMonthlyInterest();
	double monthlyInterestRate = annualInterestRate/12.0;
System.out.printf("Account ID: %d \nCurrent balance: $%.1f\nAnnual interest rate: %.3f %% \nMonthly interest rate: %.3f %% \nMonthly interest: $%.3f\n"
					,id, balance, annualInterestRate, monthlyInterestRate, monthlyInterest);
}

}

	


