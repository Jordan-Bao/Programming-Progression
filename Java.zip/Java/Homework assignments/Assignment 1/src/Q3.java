
public class Q3 {

	public static void main (String [] args) {
		
		double acceleration = 9.81;
		double timeinseconds = 12;
		double distance = acceleration*timeinseconds*timeinseconds/2.0;
		
		System.out.println("Distance after " + timeinseconds + " seconds: " + distance);
	}
}
