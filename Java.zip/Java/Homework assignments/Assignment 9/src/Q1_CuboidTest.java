
public class Q1_CuboidTest {
	public static void main (String[] args) {
		Cuboid one = new Cuboid();
		Cuboid two = new Cuboid(8, 3.5, 5.9, "Green");
		
		System.out.println("Cuboid 1");
		one.displayInfo();
		System.out.println("Cuboid 2");
		two.displayInfo();
	}

}
