
public class Q5 {

	public static void main(String[] args) {
		/* Generate a random valid license plate number */
		
		//generate the random letters using ASCII values
		int randomletter1 = (int)(26*Math.random()+1) + 64;
		char letter1 = (char)randomletter1;
		int randomletter2 = (int)(26*Math.random()+1) + 64;
		char letter2 = (char)randomletter2;
		int randomletter3 = (int)(26*Math.random()+1) + 64;
		char letter3 = (char)randomletter3;
		
		//generate the random numbers
		int number1 = (int)(10*Math.random());
		int number2 = (int)(10*Math.random());
		int number3 = (int)(10*Math.random());
		int number4 = (int)(10*Math.random());
		
		//print license plate
		System.out.printf("A random vehicle plate number: %C%C%C%d%d%d%d", letter1, letter2, letter3,
							number1, number2, number3, number4);
	}

}
