import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		// Use a method to convert user input time into a stop-watch format
		Scanner in = new Scanner (System.in);
		
		System.out.print("Enter time in seconds: ");
		int totalSeconds = in.nextInt();
		String stopwatch = covertTime(totalSeconds);
		System.out.println(stopwatch);
		
		in.close();
	}

	//Covert time method
	public static String covertTime(int totalSeconds) {
		int hours = totalSeconds/3600;
		int minutes = totalSeconds%3600/60;
		int seconds = totalSeconds%60;
		
		String stopwatch = (hours+":"+minutes+":"+seconds);
		return stopwatch;
	}
}
