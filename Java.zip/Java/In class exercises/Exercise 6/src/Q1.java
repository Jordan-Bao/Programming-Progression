
public class Q1{
	public static void  main(String[] args){
		System.out.printf("%-10s%-13s| %-12s%s%n","Celsius","Fahrenheit", "Fahrenheit","Celsius");
		for(int line=1; line<=44; line++){System.out.print("-");}
		
		int celsius1 = 20;
		
		int fahrenheit2 = 50;
				
		for (int repeat = 1; repeat<=10; repeat++){
			double fahrenheit1 = toFahrenheit(celsius1);
			double celsius2 = toCelsius(fahrenheit2);
			System.out.printf("%n%-10d%-13.2f| %-12d%-7.2f", celsius1, fahrenheit1, fahrenheit2, celsius2);
			celsius1++;
			fahrenheit2+=5;
		}
	}
	
	public static double toFahrenheit(double celsius){
		double fahrenheit = (9.0/5)*celsius+32;
	return fahrenheit;
	}	
	
	public static double toCelsius(double fahrenheit){
		double celsius = (5.0/9)*(fahrenheit-32);
	return celsius;
	}
}


