
import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		// User can generate an array of any size to track marks
		Scanner in = new Scanner(System.in);
		
		@SuppressWarnings("unused")
		int arraysize = 100;
		double nextscore;
		double total = 0;
		double [] markkeeper = new double[100];
		int x; //tracks the index
		
		System.out.print("Enter a new score (-1 to end): ");
		nextscore = in.nextDouble();
		
		for(x = 0; nextscore!=-1; x++){
			
			markkeeper [x] = nextscore;
			total = total + nextscore;
			
			System.out.print("Enter a new score (-1 to end): ");
			nextscore = in.nextDouble();
			
		}
		
		double average = total/x;
		System.out.printf("Average: %.2f%n", average);
		System.out.println("Total number of scores: " + x);
		
		int higher= 0;
		int lower = 0;
		for(int check = 0; check<x; check++)
		{ 
			if (markkeeper[check]>=average){higher++;}
			else if(markkeeper[check]<average){lower++;}
		}
		
		System.out.println("Number of scores above or equal to the average: " + higher);
		System.out.println("Number of scores below the average: " + lower);

		in.close();
	}

}
