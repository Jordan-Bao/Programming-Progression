import java.util.Scanner;
public class Q3 {
	public static void main(String[] args) {
		//Number reverser and palindrome checker
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter a positive integer: ");
		int number = in.nextInt();
		
		while(number<=0) { //Make sure the input is valid
			System.out.print("The integer needs to be positive: ");
			number = in.nextInt();}
		
		
		if (isPalindrome(number)==true) {
			System.out.println(number + " is palindrome");}
		
		else {System.out.println(number + " is not palindrome");}
		
		in.close();
		
	}

	//Reverse integer method
	public static int reverse(int number) {
	
		String before = ""+number; //Convert to string to figure out number of loops required
		int reverse = 0;
		
		for(int index=0; index<before.length(); index++) 
		{
		int next = before.charAt(index); //Take the ASCII value of where the index is at
		
		reverse = reverse + (int)((next-48)*(Math.pow(10, index))); //At each consecutive step the number is converted
		}															//to its' actual integer value (ASCII-48) then
																	//multiplied by the appropriate place value so
		return reverse;												//it can be added to the old reverse value
	}
	
	//Check if the number is a palindrome
	public static boolean isPalindrome(int number) {

		if (number==reverse(number)) {return true;}
		else {return false;}
	}
}
