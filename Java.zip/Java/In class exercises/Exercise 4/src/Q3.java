
public class Q3 {
	public static void  main (String[] args){
		//Pick a random card
		
		int card = (int)(52*Math.random());
		
		
		String rank = "initialize";
		int ranknumber = card%13;
		switch(ranknumber)
		{
		case 0 : rank = "Ace"; break;
		case 1 : rank = "2"; break;
		case 2 : rank = "3"; break;
		case 3 : rank = "4"; break;
		case 4 : rank = "5"; break;
		case 5 : rank = "6"; break;
		case 6 : rank = "7"; break;
		case 7 : rank = "8"; break;
		case 8 : rank = "9"; break;
		case 9: rank = "10"; break;
		case 10 : rank = "Jack"; break;
		case 11 : rank = "Queen"; break;
		case 12 : rank = "King"; break;
		default : rank = "This is a bug";
		}
		
		String suit = "initialize";
		int suitnumber =card/13;
		switch(suitnumber)
		{
		case 0 : suit = "Clubs"; break;
		case 1 : suit = "Diamonds"; break;
		case 2 : suit = "Spades"; break;
		case 3 :suit = "Hearts"; break;
		default : rank = "This is a bug";
		}
		
		System.out.printf("The card you picked is %s of %s", rank, suit);
		
	}
}
