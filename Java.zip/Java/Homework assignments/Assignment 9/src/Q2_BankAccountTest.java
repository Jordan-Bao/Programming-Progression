public class Q2_BankAccountTest {

	public static void main(String[] args) {
		BankAccount test = new BankAccount(6.7, 33000);
		test.withdraw(1500);
		test.deposit(1000);
	    test.displayInfo();
	}

}
