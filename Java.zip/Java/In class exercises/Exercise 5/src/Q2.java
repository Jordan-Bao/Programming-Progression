import java.util.Scanner;
public class Q2 {

	public static void main(String[] args) {
		// Finding top student's GPA
		Scanner in = new Scanner(System.in);

//prompt user to enter the number of students
System.out.print("Enter the number of students (1-30): "); 
int student = in.nextInt();
//if they enter a number outside the parameters
	while ((student<1)|(student>30))
		{  
		System.out.print("Invalid number. Try again: ");
		student = in.nextInt();
		} 
	
//initialize the array and index
double marktracker [] = new double [student]; 
int studentindex = 0;

//Loop GPA input for number of students
for (studentindex = 0; studentindex<student;studentindex++)
		{
	System.out.print("Enter the GPA of student " + (studentindex+1) + " : ");
	marktracker[studentindex] = in.nextDouble();
	//if they enter a number outside the parameters
	while ((marktracker[studentindex]<0)|(marktracker[studentindex]>4)) 
			{
			System.out.print("Invalid GPA value. Try again: ");
			marktracker[studentindex] = in.nextDouble();
			}
		}

//Find and show the top grade
double max = marktracker [0]; 
		{
for (int x = 1; x<student; x++)
	if (marktracker[x]>max)
		max = marktracker[x];
		}
System.out.println("The top GPA is " + max);

in.close();
	}

}
