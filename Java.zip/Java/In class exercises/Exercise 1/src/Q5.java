
public class Q5 {

	public static void main(String[] args) {
		// Calculate average speed in kilometers per hour
		
		/*State variables*/
		double miles = 24;
		double milestokilometer = miles*1.6;
		
		double hours = 1.0;
		
		double minutes = 40.0;
			double minutestohours = minutes/60.0;
		
		double seconds = 35.0;
			double secondstohours = seconds/3600.0;
		
		double totaltimeinhours = (hours+minutestohours+secondstohours);
		double averagespeed = milestokilometer/totaltimeinhours;
		
		/*output the average speed*/
		System.out.println("The average speed was " + averagespeed + " km/h");
				

	}

}
