import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
	//User generates a triangle with 3 double values, check if it's a valid triangle, calculate the perimeter
	Scanner in = new Scanner(System.in);
	
	System.out.print("Enter three edges (length in double): ");
	double edge1 = in.nextDouble();
	double edge2 = in.nextDouble();
	double edge3 = in.nextDouble();
	
	/*check if it's a valid triangle*/ 
	if ((edge1+edge2<=edge3)|(edge1+edge3<=edge2)|(edge2+edge3<=edge1)) 
	{System.out.println("Input is invalid");}
	
	else {
		double perimeter = edge3+edge2+edge1;
		System.out.println("The perimeter is " + perimeter);
		}
	
	in.close();
	}

}
