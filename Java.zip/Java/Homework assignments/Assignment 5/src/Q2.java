
class Q2 {

	public static void main(String[] args) {
		// Finding first 4 perfect numbers
		
		//Initialize numbers to keep track of
		int sumofdivisors = 0; 
		
		//start search at 6
		for(int number = 6; number <=10000; number++){
			
			//loop to test all possible divisors
			for(int test = 1; test<=number/2; test++){
				if (number%test==0){sumofdivisors+=test;}
			}
			//check if it is a perfect value
			if (number == sumofdivisors){
			System.out.println(number);	
			}
			//reset values before next loop
			
			@SuppressWarnings("unused")
			int test = 1; //don't need to use this
			sumofdivisors = 0;
		}
	}
}
