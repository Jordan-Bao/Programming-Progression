import java.util.Scanner;
public class Q2 {
	public static void main (String[] args) {
		//Use methods to convert 3 input side lengths into the area of a triangle
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter three sides in double: ");
		double side1 = in.nextDouble();
		double side2 = in.nextDouble();
		double side3 = in.nextDouble();
		
		//Loop if input is not valid
		while (isValid(side1, side2, side3)==false) {
			System.out.println("Invalid Input. Try again.");
			System.out.print("Enter three sides in double: ");
			side1 = in.nextDouble();
			side2 = in.nextDouble();
			side3 = in.nextDouble();}
		
		//Calculate and show area
		double trianglearea = area(side1, side2, side3);
		System.out.printf("Area: %.3f", trianglearea);
		
		in.close();
	}
	
	//Method to check validity of input
	public static boolean isValid(double side1, double side2, double side3) { 
		
		if ((side1+side2>side3)&(side1+side3>side2)&(side2+side3>side1)) {return true;}
	
		else {return false;}
	}
	//Method to calculate area
	public static double area(double side1, double side2, double side3) {
		
		double s = (side1+side2+side3)/2.0;
		double area = Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
		
		return area;
	}
}
