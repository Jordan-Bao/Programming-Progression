
public class Q1to3 {

	public static void main(String[] args) {
		int[][] m1 = { { 14, 11, 13, 12 },
					   { 18, 15, 13, 13 },
					   { 19, 16, 15, 17 } };
		
		int[][] m2 = { { 54, 53, 51, 52 },
				       { 51, 59, 52, 56 },
				       { 53, 54, 52, 58 } };
		
		int[][] m3 = { { 14, 11, 13, 12 },
				       { 18, 15, 13, 13 },
				       { 19, 16, 15, 17 } };
		
				System.out.println("First array:");
				displayArray(m1);
				System.out.println("Second array:");
				displayArray(m2);
				System.out.println("Third array:");
				displayArray(m3);
				
				//Q1
				if (equals(m1,m2)==true){
					System.out.println();
					System.out.println("Array 1 and 2 are strictly identical");}
				else if (equals(m1,m2)==false) {System.out.println();
				System.out.println("Array 1 and 2 aren't strictly identical");}
				
				if (equals(m1,m3)==true){
					System.out.println();
					System.out.println("Array 1 and 3 are strictly identical");}
				else if (equals(m1,m3)==false) {System.out.println();
				System.out.println("Array 1 and 3 aren't strictly identical");}
				
				//Q2
				shuffle(m1);
				System.out.println();
				System.out.println("This is the shuffled array 1: ");
				displayArray(m1);
				
				//Q3
				System.out.println();
				System.out.println("This is the sorted shuffled array 1: ");
				displayArray(sortRows(m1));
				
				System.out.println();
				System.out.println("This is the original shuffled array 1 : ");
				displayArray(m1);
				}
				
				public static void displayArray(int[][] m) {
				for (int r = 0; r < m.length; r++) {
				for (int c = 0; c < m[r].length; c++)
				System.out.print(m[r][c] + " ");
				System.out.println();}
				}
					   
				public static boolean equals(int[][] m1, int[][] m2) 
				{
					boolean check = false;
					
					if (m1.length != m2.length) {check = false;}
					
					
					else if(m1.length == m2.length) 
					{
						for (int a=0; a<m1.length; a++){
							for (int b=0; b<m1[0].length; b++){
								if (m1[a][b] == m2[a][b]){check = true;}
								else if(m1[a][b] != m2[a][b]) {check = false;}
							}
						}
					}
					return check;
				}
				
				public static void shuffle(int[][] m)
				{
					for (int a=0; a<m.length-1; a++)
					{
						int newrow = (int)(m.length*Math.random());
						while (newrow == a){newrow = (int)(m.length*Math.random());}
						int[] temp = m[a];
						m[a] = m[newrow];
						m[newrow] = temp;
					}
				}
				
				public static int [][] sortRows(int[][] m)
				{ //if used assign variable on array to array it copies the address not the full array 
					int[][] m1 = new int[m.length][m[0].length];
					for (int a=0; a<m.length; a++)
					{
						for(int b=0; b<m[0].length; b++)
						{
							m1[a][b] = m[a][b];
						}
					}
					
					for (int a=0; a<m1.length; a++){
						for (int b=0; b<m1[0].length-1; b++)
						{
							 while(m1[a][b]>m1[a][b+1]){
								int temp = m1[a][b+1];
								m1[a][b+1] = m1[a][b];
								m1[a][b] = temp;
								b=0;} //reset after each number has raised to the top each row 	
							 
						}
						
					}
					return m1;
				}

}
