import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		// Calculate cost of fuel with distance driven (miles), fuel economy (miles per gallon), and price of fuel per gallon ($/gallon)
		
		System.out.print("Enter the driving distance in miles: ");
		double drivingdistance = input.nextDouble();
		
		System.out.print("Enter miles per gallon: ");
		double milespergallon = input.nextDouble();
		
		System.out.print("Enter price in $ per gallon: ");
		double dollarspergallon = input.nextDouble();
		
		/*Calculate cost of driving*/
		double costofdriving = (drivingdistance/milespergallon)*dollarspergallon;
		
		System.out.println("The cost of driving is $" + costofdriving);
		
	input.close();

	}

}
