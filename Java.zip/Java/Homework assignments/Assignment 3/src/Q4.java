import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		/*Java arithmetic, augmented assignment, pre and post increment operators*/
	
		Scanner user = new Scanner(System.in);

		System.out.print("Enter a non zero number: ");
		int either = user.nextInt();
		
		//Make the user's input a random even number by multiplying
		//the input by a random multiple of 2 between 2 and 202
		either *= 2*((int)(101*Math.random())+1); // the +1 is needed so that 0s are not generated
		System.out.println("Here is a random even number generated from your number " + either);

		System.out.println("Check comments to see why the following numbers are interesting");
		
		//Interesting example: post increment or decrement does not apply on augmented assignments
		either /= either--; 
		System.out.print(either+ " "); //is still 1 therefore, variable is assigned before the decrement applies
		either /= either++; 
		System.out.println(either); //is still 1 therefore, variable is assigned before the increment applies
		
		//Pre-increment works as expected
		either -= ++either; //same as either = either - (either+1)
		System.out.println(either);
		
		user.close();
	}
	

}
