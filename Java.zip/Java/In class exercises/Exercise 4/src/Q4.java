import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		// Determine if two user generated rectangles overlap
		
		System.out.print("Enter the the x coordinate, and y coordinate of the top left corner of rectangle 1");
		double x1 = in.nextDouble();
		double y1 = in.nextDouble();
		System.out.print("Enter the width, and height of rectangle 1");
		double width1 = in.nextDouble();
		double height1 = in.nextDouble();
		
		System.out.print("Enter the the x coordinate, and y coordinate of the top left corner of rectangle 2");
		double x2 = in.nextDouble();
		double y2 = in.nextDouble();
		System.out.print("Enter the width, and height of rectangle 2");
		double width2 = in.nextDouble();
		double height2 = in.nextDouble();
		
		/*All possible configurations with 2 rectangles. This can be achieved by moving only the moving top left corner of one 
		  of them, and making the other rectangle static because each configuration is a mirror of the opposite setup,
		  which switches the two rectangles' roles. Negative dimensions would result in the user entering another corner of the 
		  rectangle so they are also ignored. The static rectangle's area will be referred to as the "boundary".
		  1: corner starts above, and to the left of the boundary 2: corner starts above, and in the middle of the boundary
		  3: corner starts above and to the right of the boundary. Overlaps only with negative dimensions. Ignore. 
		  4: corner starts middle and to the left of the boundary. 5. corner starts completely inside the boundary 
		  6: corner starts middle and to the right of the boundary. Overlaps only with negative dimensions. Ignore. 
		  7,8,9: corner starts below and to the left, middle, or right of the boundary. Overlaps only with negative dimensions. Ignore.
		  Investigate 1,2,4,5. Case 1: Overlap if x1+width1>x2 & y1-height1<y2 Case 2: Overlap if y1-height1<y2
		  Case 4: Overlap if x1+width1>x2 Case 5: Always overlaps*/
		
		//Check for negative dimensions
		if ((width1<0)|(width2<0)|(height1<0)|(height2<0))
	    System.out.println("Using negative values for the width or height results in another corner of the rectangle");
		else if ((width1==0)|(width2==0)|(height1==0)|(height2==0)) 
		System.out.println("Using zero as a width, and, or height results in a line or a dot. This is not a rectangle");
		//case 5
		else if ((x1>x2)&(x2+width2>x1)&(y2>y1)&(y1>y2-height2)
		//case 4
		|(x1<x2)&(y2>y1)&(y1>y2-height2)&(x1+width1>x2)
		//case 2		
		|(y1>y2)&(x1>x2)&(x2+width2>x1)&(y1-height1<y2)
		//case 1
		|(x1<x2)&(x1+width1>x2)&(y1-height1<y2))
		{System.out.println("The 2 rectangles overlap");}
		
		else {System.out.println("The 2 rectangles do not overlap");}
		
		in.close();
	}

}
